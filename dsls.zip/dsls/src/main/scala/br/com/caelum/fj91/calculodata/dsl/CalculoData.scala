package br.com.caelum.fj91.calculodata.dsl

import java.util.Calendar;
import Data._

object CalculoData {
  def main(args: Array[String]) = {
    println(Hoje mais 2 meses)
    println(Amanhã menos 1 mês e mais 10 anos e mais 1 dia)
  }
}